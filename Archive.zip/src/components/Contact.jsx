import { useState } from 'react';

export const Contact = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Formulario enviado:', formData);
    };

    return (
        <section id="contact" className="section min-h-screen flex items-center justify-center mb-20">
            <div className="max-w-2xl w-full mx-auto px-6">
                <h2 className="text-2xl mb-6 text-[#4b4b4b] text-center">Send me</h2>
                <p className="text-[#a1a1a1] mb-8 text-center">
                    Send me a message and I will get back to you as soon as possible.
                </p>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <input
                            type="text"
                            name="name"
                            placeholder="Nombre completo"
                            value={formData.name}
                            onChange={handleChange}
                            className="w-full px-6 py-4 border border-gray-200 rounded-lg focus:outline-none focus:border-[#535bf2] transition-colors text-lg"
                            required
                        />
                    </div>

                    <div>
                        <input
                            type="email"
                            name="email"
                            placeholder="Correo electrónico"
                            value={formData.email}
                            onChange={handleChange}
                            className="w-full px-6 py-4 border border-gray-200 rounded-lg focus:outline-none focus:border-[#535bf2] transition-colors text-lg"
                            required
                        />
                    </div>

                    <div>
                        <input
                            type="text"
                            name="subject"
                            placeholder="Asunto"
                            value={formData.subject}
                            onChange={handleChange}
                            className="w-full px-6 py-4 border border-gray-200 rounded-lg focus:outline-none focus:border-[#535bf2] transition-colors text-lg"
                            required
                        />
                    </div>

                    <div>
                        <textarea
                            name="message"
                            placeholder="Tu mensaje"
                            value={formData.message}
                            onChange={handleChange}
                            className="w-full px-6 py-4 border border-gray-200 rounded-lg focus:outline-none focus:border-[#535bf2] transition-colors min-h-40 resize-y text-lg"
                            required
                        />
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-[#535bf2] hover:bg-[#646cff] text-white py-4 px-6 rounded-lg transition-colors duration-300 text-lg font-medium"
                    >
                        Enviar mensaje
                    </button>
                </form>
            </div>
        </section>
    );
};