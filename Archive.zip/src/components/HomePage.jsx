// src/components/HomePage.jsx
import { useActiveSection } from "../hooks/useActiveSection";
import { UseDarkMode } from './themes/UseDarkMode';
import { useTheme } from './themes/ThemeContext';

export const HomePage = () => {
    const { activeSection } = useActiveSection();
    const { isDark } = useTheme();

    const navLinks = [
        { name: 'Home', path: '#home' },
        { name: 'Projects', path: '#projects' },
        { name: 'Articles', path: '#articles' },
        { name: 'Contact', path: '#contact' }
    ];

    const getLinkClasses = (path) => {
        const baseClasses = 'text-gray-900 dark:text-gray-100 transition-all duration-300';
        const hoverClasses = 'hover:text-indigo-600 dark:hover:text-indigo-400';
        const activeClasses = activeSection === path.replace('#', '')
            ? 'text-indigo-600 dark:text-indigo-400 font-medium'
            : '';

        return `${baseClasses} ${hoverClasses} ${activeClasses}`.trim();
    };

    return (
        <section id="home" className="section bg-white dark:bg-gray-900 transition-all duration-300">
            <header className="header bg-white dark:bg-gray-900 transition-all duration-300">
                <div className="nav-container">
                    <div className="logo-section">
                        <div className="logo dark:bg-white transition-all duration-300"></div>
                        <span className="brand-name text-gray-900 dark:text-white transition-all duration-300">
                            Mario Mesa Sosa
                        </span>
                    </div>
                    <nav>
                        <ul className="nav-links">
                            {navLinks.map((item, index) => (
                                <li key={index} className="flex items-center">
                                    <a
                                        href={item.path}
                                        className={getLinkClasses(item.path)}
                                    >
                                        {item.name}
                                    </a>
                                </li>
                            ))}
                            <li>
                                <UseDarkMode />
                            </li>
                        </ul>
                    </nav>
                </div>
                <div className="hero-content">
                    <h1 className="hero-title text-gray-900 dark:text-white transition-all duration-300">
                        Frontend Developer
                    </h1>
                    <p className="hero-subtitle text-gray-600 dark:text-gray-400 transition-all duration-300">
                        Un apasionado de la tecnologia y de la vida
                    </p>
                </div>
            </header>
        </section>
    );
};