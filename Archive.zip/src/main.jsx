import { ThemeProvider } from './components/themes/ThemeContext';  // Note la extensión .jsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { IndexComponent } from "./components/IndexComponent";
import { BrowserRouter } from "react-router-dom";
import './App.css'

createRoot(document.getElementById('root')).render(
    <ThemeProvider>
        <BrowserRouter>
            <StrictMode>
                <IndexComponent />
            </StrictMode>
        </BrowserRouter>
    </ThemeProvider>
)